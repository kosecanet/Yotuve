package com.jose.yotuve

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Historial local de vídeos vistos (los últimos 50), base de las recomendaciones del inicio. */
object History {
    private fun prefs() = App.instance.getSharedPreferences("historial", Context.MODE_PRIVATE)

    fun list(): List<Video> = runCatching {
        val arr = JSONArray(prefs().getString("vistos", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Video(o.getString("id"), o.optString("t"), o.optString("c"), null, null,
                "https://i.ytimg.com/vi/${o.getString("id")}/hqdefault.jpg")
        }
    }.getOrDefault(emptyList())

    fun add(v: Video) {
        val all = (listOf(v) + list().filter { it.id != v.id }).take(50)
        val arr = JSONArray()
        all.forEach { arr.put(JSONObject().put("id", it.id).put("t", it.title).put("c", it.channel)) }
        prefs().edit().putString("vistos", arr.toString()).apply()
    }
}
