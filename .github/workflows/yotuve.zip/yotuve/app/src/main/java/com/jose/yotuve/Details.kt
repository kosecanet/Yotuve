package com.jose.yotuve

import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class Comment(
    val author: String, val authorUrl: String?, val avatar: String?, val text: String,
    val likes: Long?, val time: String, val isUploader: Boolean, val pinned: Boolean,
)

data class Details(
    val description: String, val likes: Long?, val date: String?, val channel: String,
    val channelUrl: String?, val followers: Long?, val commentCount: Long?, val comments: List<Comment>,
)

data class ChannelInfo(
    val name: String, val url: String, val avatar: String?, val banner: String?,
    val followers: Long?, val description: String, val videos: List<Video>,
)

private fun JSONObject.str(k: String) = optString(k).takeIf { it.isNotEmpty() && it != "null" }
private fun JSONObject.num(k: String) = optLong(k, -1).takeIf { it >= 0 }

/** Descripción, likes, datos del canal y los comentarios más destacados de un vídeo. */
suspend fun Repo.details(v: Video): Details = withContext(Dispatchers.IO) {
    val req = YoutubeDLRequest(v.url).apply {
        addOption("-J"); addOption("--skip-download"); addOption("--no-playlist")
        addOption("--write-comments")
        addOption("--extractor-args", "youtube:max_comments=60,60,0,0;comment_sort=top")
        addOption("--no-warnings")
    }
    val j = JSONObject(execPublic(req).out)
    val arr = j.optJSONArray("comments")
    val comments = (0 until (arr?.length() ?: 0)).map { arr!!.getJSONObject(it) }
        .filter { (it.str("parent") ?: "root") == "root" }
        .map {
            Comment(
                author = it.str("author") ?: "", authorUrl = it.str("author_url"),
                avatar = it.str("author_thumbnail"), text = it.str("text") ?: "",
                likes = it.num("like_count"), time = it.str("_time_text") ?: "",
                isUploader = it.optBoolean("author_is_uploader"), pinned = it.optBoolean("is_pinned"),
            )
        }.sortedByDescending { it.pinned }
    val d = j.str("upload_date")
    Details(
        description = j.str("description") ?: "",
        likes = j.num("like_count"),
        date = d?.let { "${it.substring(6, 8)}/${it.substring(4, 6)}/${it.substring(0, 4)}" },
        channel = j.str("channel") ?: j.str("uploader") ?: v.channel,
        channelUrl = j.str("channel_url") ?: j.str("uploader_url"),
        followers = j.num("channel_follower_count"),
        commentCount = j.num("comment_count"),
        comments = comments,
    )
}

/** Página de un canal: avatar, banner, suscriptores, descripción y últimos vídeos. */
suspend fun Repo.channel(url: String): ChannelInfo = withContext(Dispatchers.IO) {
    val base = url.trimEnd('/').removeSuffix("/videos").removeSuffix("/featured")
    val req = YoutubeDLRequest("$base/videos").apply {
        addOption("--flat-playlist"); addOption("-J")
        addOption("--playlist-end", "30"); addOption("--no-warnings")
    }
    val j = JSONObject(execPublic(req).out)
    val thumbs = j.optJSONArray("thumbnails")
    fun thumb(id: String) = (0 until (thumbs?.length() ?: 0)).map { thumbs!!.getJSONObject(it) }
        .firstOrNull { it.optString("id") == id }?.str("url")
    val ents = j.optJSONArray("entries")
    val name = j.str("channel") ?: j.str("uploader") ?: (j.str("title") ?: "").substringBefore(" - ")
    val videos = (0 until (ents?.length() ?: 0)).mapNotNull { i ->
        val e = ents!!.getJSONObject(i)
        val id = e.str("id")?.takeIf { it.length == 11 } ?: return@mapNotNull null
        Video(id, e.str("title") ?: "", name, e.optDouble("duration").takeIf { !it.isNaN() }?.toLong(),
            e.num("view_count"), "https://i.ytimg.com/vi/$id/hqdefault.jpg")
    }
    ChannelInfo(
        name = name, url = base,
        avatar = thumb("avatar_uncropped"), banner = thumb("banner_uncropped"),
        followers = j.num("channel_follower_count"),
        description = j.str("description") ?: "", videos = videos,
    )
}
