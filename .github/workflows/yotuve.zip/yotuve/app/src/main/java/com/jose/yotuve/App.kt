package com.jose.yotuve

import android.app.Application
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock

class App : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        instance = this
        // Guarda cualquier cierre inesperado para mostrarlo en el siguiente arranque
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile(this).writeText(android.util.Log.getStackTraceString(e)) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
        scope.launch { kotlinx.coroutines.delay(3000); Updater.check(this@App) }   // ¿hay versión nueva de yotuve?
        scope.launch {
            try {
                YoutubeDL.getInstance().init(this@App)
                FFmpeg.getInstance().init(this@App)
                lock.lock()           // la actualización va primero; las búsquedas esperan a que termine
                ready = true
            } catch (e: Throwable) {
                Log.e("yotuve", "init yt-dlp", e)
                initError = Log.getStackTraceString(e)
                setStatus("Error iniciando yt-dlp"); return@launch
            }
            try { autoUpdate() } finally { lock.unlock() }
            if (status != null) { kotlinx.coroutines.delay(4000); setStatus(null) }
        }
    }

    /** Actualiza yt-dlp en segundo plano en cada arranque (estable; si falla, nightly). */
    private fun autoUpdate() {
            setStatus("Buscando actualizaciones…")
            val msg = try {
                when (YoutubeDL.getInstance().updateYoutubeDL(this@App, YoutubeDL.UpdateChannel.STABLE)) {
                    YoutubeDL.UpdateStatus.DONE -> "yt-dlp actualizado a ${YoutubeDL.getInstance().versionName(this@App)}"
                    else -> null // ya estaba al día: no molestamos
                }
            } catch (e: Throwable) {
                try {
                    YoutubeDL.getInstance().updateYoutubeDL(this@App, YoutubeDL.UpdateChannel.NIGHTLY); null
                } catch (_: Throwable) { Log.w("yotuve", "update", e); null }
            }
            setStatus(msg)
    }

    companion object {
        lateinit var instance: App
        @Volatile var ready = false
        /** Mensaje breve que la barra superior muestra mientras se actualiza. */
        var status by mutableStateOf<String?>(null)
        @Volatile var initError: String? = null
        /** Bloqueo compartido: la actualización y las ejecuciones de yt-dlp nunca a la vez. */
        val lock = kotlinx.coroutines.sync.Mutex()
        fun crashFile(ctx: android.content.Context) = java.io.File(ctx.filesDir, "ultimo_error.txt")
        /** Los cambios de estado de Compose siempre en el hilo principal. */
        fun setStatus(s: String?) = android.os.Handler(android.os.Looper.getMainLooper()).post { status = s }
    }
}
