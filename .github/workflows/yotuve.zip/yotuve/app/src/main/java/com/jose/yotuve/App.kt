package com.jose.yotuve

import android.app.Application
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class App : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        instance = this
        // Guarda cualquier cierre inesperado para mostrarlo en el siguiente arranque
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile(this).writeText(android.util.Log.getStackTraceString(e)) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
        scope.launch {
            try {
                YoutubeDL.getInstance().init(this@App)
                FFmpeg.getInstance().init(this@App)
                ready = true          // la app ya funciona con la versión instalada
            } catch (e: Throwable) {
                Log.e("yotuve", "init yt-dlp", e)
                initError = Log.getStackTraceString(e)
                setStatus("Error iniciando yt-dlp"); return@launch
            }
            autoUpdate()             // y en segundo plano se actualiza, sin bloquear
        }
    }

    /** Actualiza yt-dlp en segundo plano en cada arranque (estable; si falla, nightly). */
    private fun autoUpdate() {
        scope.launch {
            setStatus("Buscando actualizaciones…")
            val msg = try {
                when (YoutubeDL.getInstance().updateYoutubeDL(this@App, YoutubeDL.UpdateChannel.STABLE)) {
                    YoutubeDL.UpdateStatus.DONE -> "yt-dlp actualizado a ${YoutubeDL.getInstance().versionName(this@App)}"
                    else -> null // ya estaba al día: no molestamos
                }
            } catch (e: Throwable) {
                try {
                    YoutubeDL.getInstance().updateYoutubeDL(this@App, YoutubeDL.UpdateChannel.NIGHTLY); null
                } catch (_: Throwable) { Log.w("yotuve", "update", e); null }
            }
            setStatus(msg)
            if (msg != null) { kotlinx.coroutines.delay(4000); setStatus(null) }
        }
    }

    companion object {
        lateinit var instance: App
        @Volatile var ready = false
        /** Mensaje breve que la barra superior muestra mientras se actualiza. */
        var status by mutableStateOf<String?>(null)
        @Volatile var initError: String? = null
        fun crashFile(ctx: android.content.Context) = java.io.File(ctx.filesDir, "ultimo_error.txt")
        /** Los cambios de estado de Compose siempre en el hilo principal. */
        fun setStatus(s: String?) = android.os.Handler(android.os.Looper.getMainLooper()).post { status = s }
    }
}
