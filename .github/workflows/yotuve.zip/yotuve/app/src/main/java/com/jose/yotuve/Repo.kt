package com.jose.yotuve

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Video(
    val id: String,
    val title: String,
    val channel: String,
    val duration: Long?,      // segundos
    val views: Long?,
    val thumb: String,
) {
    val url get() = "https://www.youtube.com/watch?v=$id"
}

/** Streams separados de vídeo y audio (YouTube ya no da >360p progresivo). */
data class Streams(val video: String, val audio: String?, val title: String)

object Repo {

    private suspend fun waitReady() {
        while (!App.ready) {
            App.initError?.let { error("yt-dlp no pudo iniciarse:\n$it") }
            delay(100)
        }
    }

    /**
     * Ejecuta yt-dlp con el bloqueo compartido. Si el fichero de yt-dlp está dañado
     * (p. ej. una actualización interrumpida), lo borra, reinstala el incluido en la app y reintenta.
     */
    private suspend fun exec(req: YoutubeDLRequest, id: String? = null, cb: ((Float, Long, String) -> Unit)? = null,
                             retried: Boolean = false): com.yausername.youtubedl_android.YoutubeDLResponse {
        // Caché de yt-dlp (guarda el reproductor de YouTube ya descifrado: cada vídeo arranca mucho antes)
        req.addOption("--cache-dir", File(App.instance.cacheDir, "yt-dlp").absolutePath)
        req.addOption("--no-warnings")
        App.gate.acquire()
        val r = try {
            Result.success(YoutubeDL.getInstance().execute(req, id, cb))
        } catch (e: Exception) {
            val m = e.message ?: ""
            if ("ZipImportError" in m || "bad local file header" in m || "zipimport" in m) {
                // Fichero de yt-dlp dañado: reinstalar el incluido en la app y reintentar
                val ctx = App.instance
                File(ctx.noBackupFilesDir, "youtubedl-android/yt-dlp").deleteRecursively()
                File(ctx.applicationInfo.dataDir, "shared_prefs").listFiles()
                    ?.filter { it.name.contains("youtubedl", true) }?.forEach { it.delete() }
                YoutubeDL.getInstance().init(ctx)
                App.setStatus("yt-dlp reparado")
                runCatching { YoutubeDL.getInstance().execute(req, id, cb) }
            } else Result.failure(e)
        } finally { App.gate.release() }
        r.exceptionOrNull()?.let { e ->
            // Error de YouTube (cambió algo): actualizar yt-dlp y reintentar una vez
            val m = e.message ?: ""
            if (!retried && id == null && ("[youtube]" in m || "HTTP Error 403" in m) && App.forceUpdateIfStale())
                return exec(req, id, cb, retried = true)
            throw e
        }
        return r.getOrThrow()
    }

    suspend fun execPublic(req: YoutubeDLRequest) = exec(req)

    /** Sugerencias del buscador: el mismo endpoint que usa YouTube. */
    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        if (q.isBlank()) return@withContext emptyList()
        try {
            val u = "https://suggestqueries-clients6.youtube.com/complete/search?client=firefox&ds=yt&hl=es&gl=ES&q=" +
                URLEncoder.encode(q, "UTF-8")
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(txt).getJSONArray(1)
            List(arr.length()) { arr.getString(it) }.take(10)
        } catch (e: Exception) { emptyList() }
    }

    private fun parse(e: JSONObject): Video? {
        val id = e.optString("id").takeIf { it.length == 11 } ?: return null // solo vídeos, no canales/listas
        if (e.optString("ie_key") == "YoutubeTab") return null
        return Video(
            id = id,
            title = e.optString("title"),
            channel = e.optString("channel", e.optString("uploader", "")).let { if (it == "null") "" else it },
            duration = e.optDouble("duration").takeIf { !it.isNaN() }?.toLong(),
            views = e.optLong("view_count", -1).takeIf { it >= 0 },
            thumb = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
        )
    }

    /** Una sola ejecución de yt-dlp para varias fuentes (búsquedas y/o mixes); devuelve vídeos por fuente. */
    private suspend fun fetch(urls: List<String>, perUrl: Int): List<List<Video>> = withContext(Dispatchers.IO) {
        waitReady()
        fun req(u: List<String>) = YoutubeDLRequest(u).apply {
            addOption("--flat-playlist"); addOption("-j")
            addOption("--playlist-end", perUrl.toString())
            addOption("--no-warnings")
        }
        fun lines(out: String) = out.lines().filter { it.startsWith("{") }.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
        try {
            // Todas a la vez (más rápido: Python arranca una vez). Agrupamos por la lista de origen.
            val all = lines(exec(req(urls)).out)
            if (urls.size == 1) return@withContext listOf(all.mapNotNull(::parse))
            val groups = all.groupBy { it.optString("playlist_webpage_url", it.optString("playlist", "")) }.values
            groups.map { g -> g.mapNotNull(::parse) }
        } catch (e: Exception) {
            if (urls.size == 1) throw e
            // Si una fuente falla (p. ej. un vídeo sin mix), probamos una a una ignorando las que fallen
            urls.map { u -> runCatching { lines(exec(req(listOf(u))).out).mapNotNull(::parse) }.getOrDefault(emptyList()) }
        }
    }

    /** Búsqueda rápida con yt-dlp (--flat-playlist: no resuelve cada vídeo). */
    suspend fun search(q: String, count: Int = 25): List<Video> =
        fetch(listOf("ytsearch$count:$q"), count).flatten().distinctBy { it.id }

    /** URL del "Mix" automático de YouTube para un vídeo: son las recomendaciones de YouTube. */
    private fun mix(id: String) = "https://www.youtube.com/watch?v=$id&list=RD$id"

    /** Vídeos relacionados: mix de YouTube + más del mismo canal. */
    suspend fun related(v: Video): List<Video> {
        val urls = buildList { add(mix(v.id)); if (v.channel.isNotBlank()) add("ytsearch8:${v.channel}") }
        return interleave(fetch(urls, 20)).filter { it.id != v.id }
    }

    /**
     * Inicio personalizado como YouTube: recomendaciones de los últimos vídeos vistos
     * (mixes de YouTube) + canales recientes, mezclados y sin repetir lo ya visto.
     */
    suspend fun home(history: List<Video>): List<Video> {
        if (history.isEmpty()) return search("tendencias")
        val recent = history.take(4)
        val channels = history.map { it.channel }.filter { it.isNotBlank() }.distinct().take(2)
        val urls = recent.map { mix(it.id) } + channels.map { "ytsearch6:$it" }
        val seen = history.map { it.id }.toSet()
        val feed = interleave(fetch(urls, 12)).filter { it.id !in seen }
        return feed.ifEmpty { search("tendencias") }
    }

    /** Intercala las listas (1º de cada una, 2º de cada una…) como el inicio de YouTube. */
    private fun interleave(lists: List<List<Video>>): List<Video> {
        val out = LinkedHashMap<String, Video>()
        val max = lists.maxOfOrNull { it.size } ?: 0
        for (i in 0 until max) for (l in lists) l.getOrNull(i)?.let { out.putIfAbsent(it.id, it) }
        return out.values.toList()
    }

    private val infoCache = HashMap<String, Pair<Long, Pair<Streams, Details>>>()

    /**
     * Una sola ejecución de yt-dlp da los enlaces para reproducir y la descripción/canal.
     * Se guarda en memoria 3 h (los enlaces de YouTube caducan a las ~6 h): reabrir un vídeo es instantáneo.
     */
    suspend fun info(v: Video, maxHeight: Int = 720): Pair<Streams, Details> = withContext(Dispatchers.IO) {
        synchronized(infoCache) { infoCache[v.id] }?.let { (t, r) ->
            if (System.currentTimeMillis() - t < 3 * 3600_000L) return@withContext r
        }
        waitReady()
        val req = YoutubeDLRequest(v.url).apply {
            addOption("-J")
            addOption("-f", "bv*[height<=$maxHeight][ext=mp4]+ba[ext=m4a]/b[height<=$maxHeight]/b")
            addOption("--no-playlist")
            addOption("--extractor-args", "youtube:skip=translated_subs")
        }
        val j = JSONObject(exec(req).out)
        val rf = j.optJSONArray("requested_formats")
        val st = if (rf != null && rf.length() > 0)
            Streams(rf.getJSONObject(0).getString("url"), rf.optJSONObject(1)?.optString("url"), v.title)
        else Streams(j.getString("url"), null, v.title)
        val r = st to detailsFrom(j, v, emptyList())
        synchronized(infoCache) { infoCache[v.id] = System.currentTimeMillis() to r }
        r
    }

    suspend fun streams(v: Video, maxHeight: Int = 720): Streams = info(v, maxHeight).first

    /**
     * URL para la tele: un único stream con vídeo y audio juntos (Chromecast no puede unir
     * pistas separadas). Prioriza HLS hasta 1080p; si no, el mp4 de 360p.
     */
    suspend fun castUrl(v: Video): String = withContext(Dispatchers.IO) {
        waitReady()
        val req = YoutubeDLRequest(v.url).apply {
            addOption("-f", "b[protocol^=m3u8][height<=1080]/18/b[acodec!=none][vcodec!=none]")
            addOption("-g"); addOption("--no-playlist"); addOption("--no-warnings")
        }
        exec(req).out.lines().first { it.startsWith("http") }
    }

    /**
     * Descarga con yt-dlp + ffmpeg (mezcla vídeo+audio en mp4).
     * Devuelve el fichero local (carpeta privada de la app, compartible con FileProvider)
     * y además lo copia a Descargas/MiTube para que se vea en la galería/archivos.
     */
    suspend fun download(ctx: Context, v: Video, onProgress: (Float) -> Unit): File = withContext(Dispatchers.IO) {
        waitReady()
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "").apply { mkdirs() }
        existing(ctx, v)?.let { return@withContext it }
        val req = YoutubeDLRequest(v.url).apply {
            addOption("-f", "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/bv*[height<=1080]+ba/b")
            addOption("--merge-output-format", "mp4")
            addOption("--no-playlist")
            addOption("--restrict-filenames")
            addOption("-o", "${dir.absolutePath}/%(title).80s [${v.id}].%(ext)s")
        }
        exec(req, v.id) { p, _, _ -> onProgress(p / 100f) }
        val f = existing(ctx, v) ?: error("No se encontró el fichero descargado")
        publishToDownloads(ctx, f)
        f
    }

    /** Mata el proceso de yt-dlp de esa descarga y borra los ficheros a medias. */
    fun cancelDownload(ctx: Context, id: String) {
        runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
        ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?.listFiles { f -> f.name.contains("[$id]") && f.extension != "mp4" }
            ?.forEach { it.delete() }
        // Por si ffmpeg ya había creado el mp4 incompleto
        ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?.listFiles { f -> f.name.contains("[$id]") }?.forEach { it.delete() }
    }

    fun existing(ctx: Context, v: Video): File? =
        ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?.listFiles { f -> f.name.endsWith("[${v.id}].mp4") }
            ?.firstOrNull()

    private fun publishToDownloads(ctx: Context, f: File) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/yotuve")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return
                ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            } else {
                @Suppress("DEPRECATION")
                val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "yotuve")
                d.mkdirs(); f.copyTo(File(d, f.name), overwrite = true)
            }
        } catch (_: Exception) { }
    }

    /** Extrae el id de un enlace compartido (youtu.be, watch?v=, shorts/). */
    fun idFromLink(text: String): String? =
        Regex("""(?:v=|youtu\.be/|shorts/|embed/)([\w-]{11})""").find(text)?.groupValues?.get(1)
}
