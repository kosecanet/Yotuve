package com.jose.yotuve

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val YtRed = Color(0xFFFF0000)
private val Bg = Color(0xFF0F0F0F)
private val Sub = Color(0xFFAAAAAA)

// ---------------------------------------------------------------- ViewModel
class MainVM : ViewModel() {
    var query by mutableStateOf("")
    var suggestions by mutableStateOf<List<String>>(emptyList())
    var results by mutableStateOf<List<Video>>(emptyList())
    var related by mutableStateOf<List<Video>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var searching by mutableStateOf(false)
    var current by mutableStateOf<Video?>(null)
    var streams by mutableStateOf<Streams?>(null)
    var dlProgress by mutableStateOf<Float?>(null)
    private var sugJob: Job? = null
    private var playJob: Job? = null

    var fullscreen by mutableStateOf(false)

    // Detalles, comentarios y canal
    var details by mutableStateOf<Details?>(null)
    var showComments by mutableStateOf(false)
    var channelOpen by mutableStateOf(false)
    var channel by mutableStateOf<ChannelInfo?>(null)
    var channelError by mutableStateOf<String?>(null)
    var channelAvatar by mutableStateOf<String?>(null)
    private val channelCache = HashMap<String, ChannelInfo>()
    // Para volver al vídeo en el mismo punto tras ver un canal
    var resumeId: String? = null
    var resumePos = 0L

    fun openChannel(url: String?) {
        if (url == null) return
        channelOpen = true; channelError = null
        channelCache[url]?.let { channel = it; return }
        channel = null
        viewModelScope.launch {
            try { channel = Repo.channel(url).also { channelCache[url] = it; if (details?.channelUrl == url) channelAvatar = it.avatar } }
            catch (e: Throwable) { channelError = "No se pudo cargar el canal" }
        }
    }

    fun closeChannel() { channelOpen = false }

    var commentsLoading by mutableStateOf(false)

    /** Abre el panel de comentarios y los carga si aún no están. */
    fun openComments() {
        val v = current ?: return
        showComments = true
        if (details?.comments?.isNotEmpty() == true || commentsLoading) return
        commentsLoading = true
        viewModelScope.launch {
            val cs = runCatching { Repo.comments(v) }.getOrNull()
            if (current?.id == v.id && cs != null) details = details?.copy(comments = cs)
            commentsLoading = false
        }
    }

    init {
        home()
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(10_000)
                if (PlayerHolder.current()?.isPlaying == true || casting) saveProgress()
            }
        }
    }

    /** Guarda por dónde va el vídeo actual (o lo borra si ha terminado). */
    fun saveProgress() {
        val p = PlayerHolder.current() ?: return
        val id = PlayerHolder.loadedId ?: return
        if (casting) { CastHelper.player?.let { Positions.save(id, it.currentPosition, it.duration) }; return }
        if (p.playbackState == androidx.media3.common.Player.STATE_ENDED) Positions.clear(id)
        else if (p.isPlaying || p.currentPosition > 0) Positions.save(id, p.currentPosition, p.duration)
    }

    /** Inicio: recomendaciones a partir de lo último que has visto. */
    fun home() {
        searching = false; current = null; query = ""
        viewModelScope.launch {
            loading = true; error = null
            // Se enseña al instante el último inicio guardado y se refresca por detrás
            if (results.isEmpty()) FeedCache.load().takeIf { it.isNotEmpty() }?.let { results = it; loading = false }
            try { results = Repo.home(History.list()).also { FeedCache.save(it) } }
            catch (e: Throwable) { if (results.isEmpty()) error = e.message }
            loading = false
        }
    }

    fun onQueryChange(q: String) {
        query = q
        sugJob?.cancel()
        sugJob = viewModelScope.launch { delay(200); suggestions = Repo.suggestions(q) }
    }

    fun search(q: String, fromUser: Boolean = true) {
        if (q.isBlank()) return
        if (fromUser) query = q
        searching = false; suggestions = emptyList(); current = null
        viewModelScope.launch {
            loading = true; error = null
            try { results = Repo.search(q) } catch (e: Throwable) { error = e.message }
            loading = false
        }
    }

    var pip by mutableStateOf(false)
    var casting by mutableStateOf(false)
    var castStatus by mutableStateOf<String?>(null)

    /** La tele se ha conectado: pasamos el vídeo actual allí desde el mismo punto. */
    fun startCast() {
        casting = true
        current?.let { castLoad(it, PlayerHolder.current()?.currentPosition ?: 0L) }
    }

    /** La tele se ha desconectado: seguimos en el móvil donde iba. */
    fun stopCast() {
        val pos = CastHelper.player?.currentPosition ?: 0L
        casting = false; castStatus = null
        PlayerHolder.current()?.let { if (PlayerHolder.loadedId == current?.id) { it.seekTo(pos); it.play() } }
    }

    private fun castLoad(v: Video, pos: Long) {
        PlayerHolder.current()?.pause()
        castStatus = "Enviando a la TV…"
        viewModelScope.launch {
            try { CastHelper.load(v, Repo.castUrl(v), pos); castStatus = "Reproduciendo en la TV" }
            catch (e: Exception) { castStatus = "No se pudo enviar a la TV" }
        }
    }
    var dlId by mutableStateOf<String?>(null)   // vídeo que se está descargando

    /** Cierra el vídeo y para el sonido (como al salir del reproductor en YouTube). */
    fun closeVideo() {
        saveProgress()
        current = null; fullscreen = false; showComments = false
        if (casting) CastHelper.player?.stop()
        PlayerHolder.current()?.let { it.stop(); it.clearMediaItems() }
        PlayerHolder.loadedId = null
    }

    fun play(v: Video) {
        History.add(v)
        saveProgress()
        if (PlayerHolder.loadedId != v.id) { PlayerHolder.current()?.stop(); PlayerHolder.loadedId = null }
        current = v; streams = null; error = null
        dlProgress = if (dlId == v.id) dlProgress else null
        details = null; showComments = false; channelAvatar = null; related = emptyList()
        if (casting) castLoad(v, Positions.get(v.id))
        playJob?.cancel()
        playJob = viewModelScope.launch {
            // 1º lo urgente: enlaces + descripción en una sola llamada → el vídeo empieza cuanto antes
            try {
                val (st, d) = Repo.info(v)
                if (current?.id != v.id) return@launch
                streams = st; details = d
            } catch (e: Exception) { error = "No se pudo reproducir: ${e.message}"; return@launch }
            // 2º relacionados, 3º comentarios, 4º avatar del canal: de uno en uno para no frenar el vídeo
            val rel = runCatching { Repo.related(v) }.getOrDefault(emptyList())
            if (current?.id != v.id) return@launch
            related = rel
            // Comentarios y canal ya NO se piden automáticamente (cada uno es un proceso de yt-dlp
            // que gasta batería): solo al abrir los comentarios o el canal.
            details?.channelUrl?.let { url -> channelAvatar = channelCache[url]?.avatar }
        }
    }

    private var retriedId: String? = null

    /** Si el reproductor falla (enlace caducado, caché dañada…), pide enlaces nuevos y sigue en el mismo punto. */
    fun recoverPlayback() {
        val v = current ?: return
        if (retriedId == v.id) { error = "No se pudo reproducir este vídeo"; return }
        retriedId = v.id
        saveProgress()
        Repo.invalidate(v.id)
        PlayerHolder.current()?.stop(); PlayerHolder.loadedId = null
        streams = null
        viewModelScope.launch {
            try { streams = Repo.info(v).first } catch (e: Exception) { error = "No se pudo reproducir: ${e.message}" }
        }
    }

    private var cancelled = false

    fun download(ctx: Context, share: Boolean) {
        val v = current ?: return
        if (dlId != null) {
            Toast.makeText(ctx, "Espera a que termine la descarga actual o cancélala", Toast.LENGTH_SHORT).show(); return
        }
        dlId = v.id; cancelled = false
        viewModelScope.launch {
            dlProgress = 0f
            try {
                val f = Repo.download(ctx, v) { p -> if (current?.id == v.id) dlProgress = p.coerceIn(0f, 0.99f) }
                if (current?.id == v.id) dlProgress = 1f
                if (share) shareFile(ctx, f, v.title)
                else Toast.makeText(ctx, "Guardado en Descargas/yotuve", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                if (current?.id == v.id) dlProgress = null
                if (cancelled) Toast.makeText(ctx, "Descarga cancelada", Toast.LENGTH_SHORT).show()
                else Toast.makeText(ctx, "Error al descargar: ${e.message}", Toast.LENGTH_LONG).show()
            } finally { dlId = null }
        }
    }

    /** Para la descarga en curso y borra el fichero a medias. */
    fun cancelDownload(ctx: Context) {
        val id = dlId ?: return
        cancelled = true
        Repo.cancelDownload(ctx, id)
    }
}

private fun shareFile(ctx: Context, f: File, title: String) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Compartir vídeo"))
}

// ---------------------------------------------------------------- Activity
class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = App.crashFile(this)
        val lastCrash = if (crashFile.exists()) crashFile.readText().also { crashFile.delete() } else null
        if (lastCrash == null) handleShare(intent)
        CastHelper.init(this, object : androidx.media3.cast.SessionAvailabilityListener {
            override fun onCastSessionAvailable() = vm.startCast()
            override fun onCastSessionUnavailable() = vm.stopCast()
        })
        if (CastHelper.isCasting) vm.casting = true
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Bg, primary = YtRed)) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    var crash by remember { mutableStateOf(lastCrash) }
                    if (crash != null) CrashScreen(crash!!) { crash = null } else AppScreen(vm)
                }
            }
        }
    }

    private var controller: com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController>? = null

    override fun onStart() {
        super.onStart()
        Quality.videoEnabled(true)
        // Arranca/conecta el servicio de reproducción (sonido con el móvil bloqueado)
        val token = androidx.media3.session.SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controller = androidx.media3.session.MediaController.Builder(this, token).buildAsync()
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onStop() {
        vm.saveProgress()
        // Con la pantalla apagada o la app en segundo plano no se descarga ni decodifica el vídeo: solo audio
        if (!isInPictureInPictureMode) Quality.videoEnabled(false)
        controller?.let { androidx.media3.session.MediaController.releaseFuture(it) }
        controller = null
        super.onStop()
    }

    /** Ventana flotante (picture-in-picture) con el vídeo. */
    fun enterPip() {
        if (vm.current == null) return
        val params = android.app.PictureInPictureParams.Builder().setAspectRatio(android.util.Rational(16, 9)).build()
        runCatching { enterPictureInPictureMode(params) }
    }

    /** Al pulsar Inicio con un vídeo sonando, pasa a ventana flotante automáticamente. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.current != null && PlayerHolder.current()?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        vm.pip = isInPip
        // Si cierras la ventana flotante con la X, se para (como YouTube)
        if (!isInPip && !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) {
            // Se cerró la ventana flotante con la X: parar, quitar la notificación y cerrar la app
            vm.closeVideo()
            stopService(Intent(this, PlaybackService::class.java))
            finishAndRemoveTask()
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleShare(intent) }

    private fun handleShare(i: Intent?) {
        val text = i?.takeIf { it.action == Intent.ACTION_SEND }?.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val id = Repo.idFromLink(text) ?: return
        vm.play(Video(id, i.getStringExtra(Intent.EXTRA_SUBJECT) ?: "Vídeo compartido", "", null, null,
            "https://i.ytimg.com/vi/$id/hqdefault.jpg"))
    }
}

// ---------------------------------------------------------------- UI
@Composable
fun CrashScreen(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("yotuve se cerró la última vez", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Haz una captura de esto y mándasela a Claude.", color = Sub, fontSize = 13.sp)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(Icons.Default.ContentCopy, "Copiar") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("error", text))
            }
            Pill(Icons.Default.Close, "Continuar", onClose)
        }
        LazyColumn { item { Text(text, fontSize = 11.sp, color = Color(0xFFFF8A80)) } }
    }
}

@Composable
fun AppScreen(vm: MainVM) {
    BackHandler(vm.current != null || vm.searching || vm.channelOpen) {
        when {
            vm.fullscreen -> vm.fullscreen = false
            vm.channelOpen -> vm.closeChannel()
            vm.searching -> vm.searching = false
            else -> vm.closeVideo()   // vuelve a la lista anterior (búsqueda o inicio)
        }
    }
    Column(if (vm.fullscreen || vm.pip) Modifier.fillMaxSize() else Modifier.fillMaxSize().statusBarsPadding()) {
        when {
            vm.pip && vm.current != null -> PlayerScreen(vm, vm.current!!)
            vm.searching -> SearchScreen(vm)
            vm.channelOpen -> ChannelScreen(vm)
            vm.current != null -> PlayerScreen(vm, vm.current!!)
            else -> {
                TopBar(onSearch = { vm.searching = true }, onHome = { vm.home() })
                Feed(vm, vm.results)
            }
        }
    }
}

@Composable
fun TopBar(onSearch: () -> Unit, onHome: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.clickable(onClick = onHome), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(Color(0xFFF2383A)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(6.dp))
        Text("yotuve", fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = (-1).sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "Buscar") }
    }
    UpdateBanner()
    App.status?.let {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sync, null, tint = Sub, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(it, color = Sub, fontSize = 12.sp)
        }
    }
}

/** Aviso de nueva versión de yotuve bajo la barra superior. */
@Composable
fun UpdateBanner() {
    val st = Updater.state ?: return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val (text, action) = when (st) {
        is Updater.State.Available -> "Nueva versión ${st.version} (${st.sizeMb} MB)" to "Descargar"
        is Updater.State.Downloading -> "Descargando versión ${st.version}… ${(st.progress * 100).toInt()} %" to null
        is Updater.State.Ready -> "Versión ${st.version} lista" to "Instalar"
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(10.dp))
        .background(Color(0xFF1E3A5F)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.SystemUpdate, null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        if (action != null) Text(action, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF8AB4F8),
            modifier = Modifier.clickable {
                when (st) {
                    is Updater.State.Available -> scope.launch { Updater.download(ctx.applicationContext) }
                    is Updater.State.Ready -> Updater.install(ctx)
                    else -> {}
                }
            }.padding(4.dp))
    }
}

@Composable
fun SearchScreen(vm: MainVM) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { vm.searching = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Atrás") }
        TextField(
            value = vm.query, onValueChange = vm::onQueryChange,
            placeholder = { Text("Buscar en YouTube") },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF272727), unfocusedContainerColor = Color(0xFF272727),
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
            trailingIcon = { if (vm.query.isNotEmpty()) IconButton(onClick = { vm.onQueryChange("") }) { Icon(Icons.Default.Close, null) } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(vm.query) }),
            modifier = Modifier.weight(1f).focusRequester(fr),
        )
    }
    LazyColumn {
        items(vm.suggestions) { s ->
            Row(Modifier.fillMaxWidth().clickable { vm.search(s) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Sub)
                Spacer(Modifier.width(16.dp))
                Text(s, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Icon(Icons.Default.NorthWest, "Completar", tint = Sub,
                    modifier = Modifier.clickable { vm.onQueryChange("$s ") })
            }
        }
    }
}

@Composable
fun Feed(vm: MainVM, list: List<Video>, header: (@Composable () -> Unit)? = null) {
    LazyColumn(Modifier.fillMaxSize()) {
        header?.let { item { it() } }
        if (vm.loading && vm.current == null) item {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = YtRed) }
        }
        vm.error?.let { if (vm.current == null) item { Text(it, color = YtRed, modifier = Modifier.padding(16.dp)) } }
        items(list, key = { it.id + list.indexOf(it) }) { v -> VideoCard(v) { vm.play(v) } }
    }
}

@Composable
fun VideoCard(v: Video, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(bottom = 16.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            AsyncImage(v.thumb, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().background(Color(0xFF222222)))
            Positions.progress(v.id)?.let { prog ->
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x88FFFFFF))) {
                    Box(Modifier.fillMaxWidth(prog).fillMaxHeight().background(YtRed))
                }
            }
            v.duration?.let {
                Text(fmtDur(it), fontSize = 12.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp))
            }
        }
        Row(Modifier.padding(12.dp)) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF3A3A3A)), contentAlignment = Alignment.Center) {
                Text(v.channel.take(1).uppercase(), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
                Text(listOfNotNull(v.channel.ifBlank { null }, v.views?.let { fmtViews(it) }).joinToString(" · "),
                    color = Sub, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: MainVM, v: Video) {
    val ctx = LocalContext.current
    val player = remember { PlayerHolder.get(ctx) }
    // Pantalla siempre encendida mientras el vídeo se reproduce (se apaga sola en pausa o al salir)
    val window = (ctx as? android.app.Activity)?.window
    DisposableEffect(player) {
        fun apply(playing: Boolean) {
            if (playing) window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        val l = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = apply(isPlaying)
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) = vm.recoverPlayback()
        }
        player.addListener(l); apply(player.isPlaying)
        onDispose { player.removeListener(l); apply(false) }
    }
    // Calidad según el tamaño real del vídeo en pantalla (y menos con datos móviles)
    val target = Quality.target(ctx, vm.fullscreen, vm.pip)
    LaunchedEffect(vm.streams, target) {
        val st = vm.streams ?: return@LaunchedEffect
        val url = st.videoFor(target)
        if (PlayerHolder.loadedId != v.id) {   // si ya está sonando (p. ej. volviendo del canal) no se reinicia
            val saved = Positions.get(v.id)   // continúa donde lo dejaste
            player.setMediaSource(PlayerCache.source(ctx, v, st, url), saved); player.prepare()
            if (saved > 0) Toast.makeText(ctx, "Continuando desde ${fmtDur(saved / 1000)}", Toast.LENGTH_SHORT).show()
            player.playWhenReady = !vm.casting   // si está en la TV, en el móvil queda en pausa
            PlayerHolder.loadedId = v.id; PlayerHolder.loadedUrl = url
        } else if (PlayerHolder.loadedUrl != url) {
            // Cambio de calidad (pantalla completa / flotante) en el mismo punto
            val pos = player.currentPosition
            player.setMediaSource(PlayerCache.source(ctx, v, st, url), pos); player.prepare()
            PlayerHolder.loadedUrl = url
        }
    }
    CommentsSheet(vm)

    val compact = vm.fullscreen || vm.pip
    FullscreenEffect(vm.fullscreen && !vm.pip)
    val boxMod = if (compact) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
    Box(boxMod.background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                    // Muestra el botón de pantalla completa en los controles
                    setFullscreenButtonClickListener { full -> vm.fullscreen = full }
                }
            },
            update = {
                // Mientras se envía a la TV, los controles manejan la TV
                val target = if (vm.casting) CastHelper.player ?: player else player
                if (it.player !== target) it.player = target
                it.setFullscreenButtonState(vm.fullscreen)
                it.useController = !vm.pip          // en la ventana flotante, solo el vídeo
            },
            onRelease = { it.player = null },
            modifier = Modifier.fillMaxSize(),
        )
        if (vm.casting) Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Cast, null, tint = Color.White, modifier = Modifier.size(40.dp))
            Text(vm.castStatus ?: "Conectado a la TV", color = Color.White, fontSize = 14.sp)
        } else if (vm.streams == null && vm.error == null) CircularProgressIndicator(color = YtRed)
        vm.error?.let { Text(it, color = Color.White, modifier = Modifier.padding(16.dp)) }
    }
    if (compact) return

    var castChoice by remember { mutableStateOf(false) }
    if (castChoice) AlertDialog(
        onDismissRequest = { castChoice = false },
        title = { Text("Enviar a la TV") },
        text = {
            Column {
                Row(Modifier.fillMaxWidth().clickable {
                    castChoice = false
                    if (CastHelper.player == null || !CastHelper.chooseDevice(ctx)) {
                        Toast.makeText(ctx, "Chromecast no disponible en este móvil; usa duplicar pantalla", Toast.LENGTH_LONG).show()
                    }
                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Cast, null); Spacer(Modifier.width(14.dp))
                    Column { Text("Chromecast / Google TV"); Text("El vídeo se reproduce en la tele; el móvil hace de mando", color = Sub, fontSize = 12.sp) }
                }
                Row(Modifier.fillMaxWidth().clickable { castChoice = false; CastHelper.openScreenMirroring(ctx) }
                    .padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ScreenShare, null); Spacer(Modifier.width(14.dp))
                    Column { Text("Duplicar pantalla"); Text("Smart View, Miracast… (teles Samsung, LG, etc.)", color = Sub, fontSize = 12.sp) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { castChoice = false }) { Text("Cancelar") } },
    )

    Feed(vm, vm.related, header = {
        Column(Modifier.padding(12.dp)) {
            Text(v.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            DetailsSection(vm, v)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(if (vm.casting) Icons.Default.CastConnected else Icons.Default.Cast,
                    if (vm.casting) "Desconectar TV" else "Enviar a TV") {
                    if (vm.casting) CastHelper.disconnect(ctx) else castChoice = true
                }
                Pill(Icons.Default.PictureInPictureAlt, "Flotante") { (ctx as? MainActivity)?.enterPip() }
                Pill(Icons.Default.Download, if (vm.dlProgress == 1f) "Descargado" else "Descargar") { vm.download(ctx, share = false) }
                Pill(Icons.Default.Share, "Compartir") { vm.download(ctx, share = true) }
                Pill(Icons.Default.Link, "Enlace") {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, v.url), "Compartir enlace"))
                }
            }
            vm.dlProgress?.takeIf { it < 1f }?.let {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        LinearProgressIndicator(progress = { it }, color = YtRed, modifier = Modifier.fillMaxWidth())
                        Text("Descargando… ${(it * 100).toInt()} %", color = Sub, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Pill(Icons.Default.Close, "Cancelar") { vm.cancelDownload(ctx) }
                }
            }
            HorizontalDivider(Modifier.padding(top = 12.dp), color = Color(0xFF272727))
        }
    })
}

/** Pantalla completa: horizontal y sin barras del sistema; al salir, todo vuelve a la normalidad. */
@Composable
fun FullscreenEffect(full: Boolean) {
    val act = LocalContext.current as? android.app.Activity ?: return
    DisposableEffect(full) {
        val ctl = androidx.core.view.WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (full) {
            act.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            act.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }
}

@Composable
fun Pill(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF272727)).clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

fun fmtDur(s: Long) = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
private fun fmtViews(n: Long) = when {
    n >= 1_000_000 -> "%.1f M visualizaciones".format(n / 1e6)
    n >= 1_000 -> "%d K visualizaciones".format(n / 1000)
    else -> "$n visualizaciones"
}
