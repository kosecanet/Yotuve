package com.jose.yotuve

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val YtRed = Color(0xFFFF0000)
private val Bg = Color(0xFF0F0F0F)
private val Sub = Color(0xFFAAAAAA)

// ---------------------------------------------------------------- ViewModel
class MainVM : ViewModel() {
    var query by mutableStateOf("")
    var suggestions by mutableStateOf<List<String>>(emptyList())
    var results by mutableStateOf<List<Video>>(emptyList())
    var related by mutableStateOf<List<Video>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var searching by mutableStateOf(false)
    var current by mutableStateOf<Video?>(null)
    var streams by mutableStateOf<Streams?>(null)
    var dlProgress by mutableStateOf<Float?>(null)
    private var sugJob: Job? = null
    private var playJob: Job? = null

    var fullscreen by mutableStateOf(false)

    // Detalles, comentarios y canal
    var details by mutableStateOf<Details?>(null)
    var showComments by mutableStateOf(false)
    var channelOpen by mutableStateOf(false)
    var channel by mutableStateOf<ChannelInfo?>(null)
    var channelError by mutableStateOf<String?>(null)
    var channelAvatar by mutableStateOf<String?>(null)
    private val channelCache = HashMap<String, ChannelInfo>()
    // Para volver al vídeo en el mismo punto tras ver un canal
    var resumeId: String? = null
    var resumePos = 0L

    fun openChannel(url: String?) {
        if (url == null) return
        channelOpen = true; channelError = null
        channelCache[url]?.let { channel = it; return }
        channel = null
        viewModelScope.launch {
            try { channel = Repo.channel(url).also { channelCache[url] = it } }
            catch (e: Throwable) { channelError = "No se pudo cargar el canal" }
        }
    }

    fun closeChannel() { channelOpen = false }

    init {
        home()
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(5_000)
                saveProgress()
            }
        }
    }

    /** Guarda por dónde va el vídeo actual (o lo borra si ha terminado). */
    fun saveProgress() {
        val p = PlayerHolder.current() ?: return
        val id = PlayerHolder.loadedId ?: return
        if (casting) { CastHelper.player?.let { Positions.save(id, it.currentPosition, it.duration) }; return }
        if (p.playbackState == androidx.media3.common.Player.STATE_ENDED) Positions.clear(id)
        else if (p.isPlaying || p.currentPosition > 0) Positions.save(id, p.currentPosition, p.duration)
    }

    /** Inicio: recomendaciones a partir de lo último que has visto. */
    fun home() {
        searching = false; current = null; query = ""
        viewModelScope.launch {
            loading = true; error = null
            try { results = Repo.home(History.list()) } catch (e: Throwable) { error = e.message }
            loading = false
        }
    }

    fun onQueryChange(q: String) {
        query = q
        sugJob?.cancel()
        sugJob = viewModelScope.launch { delay(200); suggestions = Repo.suggestions(q) }
    }

    fun search(q: String, fromUser: Boolean = true) {
        if (q.isBlank()) return
        if (fromUser) query = q
        searching = false; suggestions = emptyList(); current = null
        viewModelScope.launch {
            loading = true; error = null
            try { results = Repo.search(q) } catch (e: Throwable) { error = e.message }
            loading = false
        }
    }

    var pip by mutableStateOf(false)
    var casting by mutableStateOf(false)
    var castStatus by mutableStateOf<String?>(null)

    /** La tele se ha conectado: pasamos el vídeo actual allí desde el mismo punto. */
    fun startCast() {
        casting = true
        current?.let { castLoad(it, PlayerHolder.current()?.currentPosition ?: 0L) }
    }

    /** La tele se ha desconectado: seguimos en el móvil donde iba. */
    fun stopCast() {
        val pos = CastHelper.player?.currentPosition ?: 0L
        casting = false; castStatus = null
        PlayerHolder.current()?.let { if (PlayerHolder.loadedId == current?.id) { it.seekTo(pos); it.play() } }
    }

    private fun castLoad(v: Video, pos: Long) {
        PlayerHolder.current()?.pause()
        castStatus = "Enviando a la TV…"
        viewModelScope.launch {
            try { CastHelper.load(v, Repo.castUrl(v), pos); castStatus = "Reproduciendo en la TV" }
            catch (e: Exception) { castStatus = "No se pudo enviar a la TV" }
        }
    }
    var dlId by mutableStateOf<String?>(null)   // vídeo que se está descargando

    /** Cierra el vídeo y para el sonido (como al salir del reproductor en YouTube). */
    fun closeVideo() {
        saveProgress()
        current = null; fullscreen = false; showComments = false
        if (casting) CastHelper.player?.stop()
        PlayerHolder.current()?.let { it.stop(); it.clearMediaItems() }
        PlayerHolder.loadedId = null
    }

    fun play(v: Video) {
        History.add(v)
        saveProgress()
        if (PlayerHolder.loadedId != v.id) { PlayerHolder.current()?.stop(); PlayerHolder.loadedId = null }
        current = v; streams = null; error = null
        dlProgress = if (dlId == v.id) dlProgress else null
        playJob?.cancel()
        playJob = viewModelScope.launch {
            try { streams = Repo.streams(v) } catch (e: Exception) { error = "No se pudo reproducir: ${e.message}" }
        }
        details = null; showComments = false; channelAvatar = null
        viewModelScope.launch {
            val d = try { Repo.details(v) } catch (_: Exception) { null }
            if (current?.id != v.id) return@launch
            details = d
            // En segundo plano: datos del canal (avatar) para que "Ver canal" abra al instante
            d?.channelUrl?.let { url ->
                val c = channelCache[url] ?: runCatching { Repo.channel(url) }.getOrNull()?.also { channelCache[url] = it }
                if (current?.id == v.id) channelAvatar = c?.avatar
            }
        }
        if (casting) castLoad(v, Positions.get(v.id))
        viewModelScope.launch {
            related = emptyList()
            related = try { Repo.related(v) } catch (_: Exception) { emptyList() }
        }
    }

    private var cancelled = false

    fun download(ctx: Context, share: Boolean) {
        val v = current ?: return
        if (dlId != null) {
            Toast.makeText(ctx, "Espera a que termine la descarga actual o cancélala", Toast.LENGTH_SHORT).show(); return
        }
        dlId = v.id; cancelled = false
        viewModelScope.launch {
            dlProgress = 0f
            try {
                val f = Repo.download(ctx, v) { p -> if (current?.id == v.id) dlProgress = p.coerceIn(0f, 0.99f) }
                if (current?.id == v.id) dlProgress = 1f
                if (share) shareFile(ctx, f, v.title)
                else Toast.makeText(ctx, "Guardado en Descargas/yotuve", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                if (current?.id == v.id) dlProgress = null
                if (cancelled) Toast.makeText(ctx, "Descarga cancelada", Toast.LENGTH_SHORT).show()
                else Toast.makeText(ctx, "Error al descargar: ${e.message}", Toast.LENGTH_LONG).show()
            } finally { dlId = null }
        }
    }

    /** Para la descarga en curso y borra el fichero a medias. */
    fun cancelDownload(ctx: Context) {
        val id = dlId ?: return
        cancelled = true
        Repo.cancelDownload(ctx, id)
    }
}

private fun shareFile(ctx: Context, f: File, title: String) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Compartir vídeo"))
}

// ---------------------------------------------------------------- Activity
class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = App.crashFile(this)
        val lastCrash = if (crashFile.exists()) crashFile.readText().also { crashFile.delete() } else null
        if (lastCrash == null) handleShare(intent)
        CastHelper.init(this, object : androidx.media3.cast.SessionAvailabilityListener {
            override fun onCastSessionAvailable() = vm.startCast()
            override fun onCastSessionUnavailable() = vm.stopCast()
        })
        if (CastHelper.isCasting) vm.casting = true
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Bg, primary = YtRed)) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    var crash by remember { mutableStateOf(lastCrash) }
                    if (crash != null) CrashScreen(crash!!) { crash = null } else AppScreen(vm)
                }
            }
        }
    }

    private var controller: com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController>? = null

    override fun onStart() {
        super.onStart()
        // Arranca/conecta el servicio de reproducción (sonido con el móvil bloqueado)
        val token = androidx.media3.session.SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controller = androidx.media3.session.MediaController.Builder(this, token).buildAsync()
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onStop() {
        vm.saveProgress()
        controller?.let { androidx.media3.session.MediaController.releaseFuture(it) }
        controller = null
        super.onStop()
    }

    /** Ventana flotante (picture-in-picture) con el vídeo. */
    fun enterPip() {
        if (vm.current == null) return
        val params = android.app.PictureInPictureParams.Builder().setAspectRatio(android.util.Rational(16, 9)).build()
        runCatching { enterPictureInPictureMode(params) }
    }

    /** Al pulsar Inicio con un vídeo sonando, pasa a ventana flotante automáticamente. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.current != null && PlayerHolder.current()?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        vm.pip = isInPip
        // Si cierras la ventana flotante con la X, se para (como YouTube)
        if (!isInPip && !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED))
            PlayerHolder.current()?.pause()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleShare(intent) }

    private fun handleShare(i: Intent?) {
        val text = i?.takeIf { it.action == Intent.ACTION_SEND }?.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val id = Repo.idFromLink(text) ?: return
        vm.play(Video(id, i.getStringExtra(Intent.EXTRA_SUBJECT) ?: "Vídeo compartido", "", null, null,
            "https://i.ytimg.com/vi/$id/hqdefault.jpg"))
    }
}

// ---------------------------------------------------------------- UI
@Composable
fun CrashScreen(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("yotuve se cerró la última vez", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Haz una captura de esto y mándasela a Claude.", color = Sub, fontSize = 13.sp)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(Icons.Default.ContentCopy, "Copiar") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("error", text))
            }
            Pill(Icons.Default.Close, "Continuar", onClose)
        }
        LazyColumn { item { Text(text, fontSize = 11.sp, color = Color(0xFFFF8A80)) } }
    }
}

@Composable
fun AppScreen(vm: MainVM) {
    BackHandler(vm.current != null || vm.searching || vm.channelOpen) {
        when {
            vm.fullscreen -> vm.fullscreen = false
            vm.channelOpen -> vm.closeChannel()
            vm.searching -> vm.searching = false
            else -> vm.closeVideo()   // vuelve a la lista anterior (búsqueda o inicio)
        }
    }
    Column(if (vm.fullscreen || vm.pip) Modifier.fillMaxSize() else Modifier.fillMaxSize().statusBarsPadding()) {
        when {
            vm.pip && vm.current != null -> PlayerScreen(vm, vm.current!!)
            vm.searching -> SearchScreen(vm)
            vm.channelOpen -> ChannelScreen(vm)
            vm.current != null -> PlayerScreen(vm, vm.current!!)
            else -> {
                TopBar(onSearch = { vm.searching = true }, onHome = { vm.home() })
                Feed(vm, vm.results)
            }
        }
    }
}

@Composable
fun TopBar(onSearch: () -> Unit, onHome: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.clickable(onClick = onHome), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(Color(0xFFF2383A)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(6.dp))
        Text("yotuve", fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = (-1).sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "Buscar") }
    }
    App.status?.let {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sync, null, tint = Sub, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(it, color = Sub, fontSize = 12.sp)
        }
    }
}

@Composable
fun SearchScreen(vm: MainVM) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { vm.searching = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Atrás") }
        TextField(
            value = vm.query, onValueChange = vm::onQueryChange,
            placeholder = { Text("Buscar en YouTube") },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF272727), unfocusedContainerColor = Color(0xFF272727),
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
            trailingIcon = { if (vm.query.isNotEmpty()) IconButton(onClick = { vm.onQueryChange("") }) { Icon(Icons.Default.Close, null) } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(vm.query) }),
            modifier = Modifier.weight(1f).focusRequester(fr),
        )
    }
    LazyColumn {
        items(vm.suggestions) { s ->
            Row(Modifier.fillMaxWidth().clickable { vm.search(s) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Sub)
                Spacer(Modifier.width(16.dp))
                Text(s, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Icon(Icons.Default.NorthWest, "Completar", tint = Sub,
                    modifier = Modifier.clickable { vm.onQueryChange("$s ") })
            }
        }
    }
}

@Composable
fun Feed(vm: MainVM, list: List<Video>, header: (@Composable () -> Unit)? = null) {
    LazyColumn(Modifier.fillMaxSize()) {
        header?.let { item { it() } }
        if (vm.loading && vm.current == null) item {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = YtRed) }
        }
        vm.error?.let { if (vm.current == null) item { Text(it, color = YtRed, modifier = Modifier.padding(16.dp)) } }
        items(list, key = { it.id + list.indexOf(it) }) { v -> VideoCard(v) { vm.play(v) } }
    }
}

@Composable
fun VideoCard(v: Video, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(bottom = 16.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            AsyncImage(v.thumb, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().background(Color(0xFF222222)))
            Positions.progress(v.id)?.let { prog ->
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x88FFFFFF))) {
                    Box(Modifier.fillMaxWidth(prog).fillMaxHeight().background(YtRed))
                }
            }
            v.duration?.let {
                Text(fmtDur(it), fontSize = 12.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp))
            }
        }
        Row(Modifier.padding(12.dp)) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF3A3A3A)), contentAlignment = Alignment.Center) {
                Text(v.channel.take(1).uppercase(), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
                Text(listOfNotNull(v.channel.ifBlank { null }, v.views?.let { fmtViews(it) }).joinToString(" · "),
                    color = Sub, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: MainVM, v: Video) {
    val ctx = LocalContext.current
    val player = remember { PlayerHolder.get(ctx) }
    LaunchedEffect(vm.streams) {
        val st = vm.streams ?: return@LaunchedEffect
        if (PlayerHolder.loadedId != v.id) {   // si ya está sonando (p. ej. volviendo del canal) no se reinicia
            val saved = Positions.get(v.id)   // continúa donde lo dejaste
            player.setMediaSource(PlayerCache.source(ctx, v, st), saved); player.prepare()
            if (saved > 0) Toast.makeText(ctx, "Continuando desde ${fmtDur(saved / 1000)}", Toast.LENGTH_SHORT).show()
            player.playWhenReady = !vm.casting   // si está en la TV, en el móvil queda en pausa
            PlayerHolder.loadedId = v.id
        }
    }
    CommentsSheet(vm)

    val compact = vm.fullscreen || vm.pip
    FullscreenEffect(vm.fullscreen && !vm.pip)
    val boxMod = if (compact) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
    Box(boxMod.background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                    // Muestra el botón de pantalla completa en los controles
                    setFullscreenButtonClickListener { full -> vm.fullscreen = full }
                }
            },
            update = {
                // Mientras se envía a la TV, los controles manejan la TV
                val target = if (vm.casting) CastHelper.player ?: player else player
                if (it.player !== target) it.player = target
                it.setFullscreenButtonState(vm.fullscreen)
                it.useController = !vm.pip          // en la ventana flotante, solo el vídeo
            },
            onRelease = { it.player = null },
            modifier = Modifier.fillMaxSize(),
        )
        if (vm.casting) Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Cast, null, tint = Color.White, modifier = Modifier.size(40.dp))
            Text(vm.castStatus ?: "Conectado a la TV", color = Color.White, fontSize = 14.sp)
        } else if (vm.streams == null && vm.error == null) CircularProgressIndicator(color = YtRed)
        vm.error?.let { Text(it, color = Color.White, modifier = Modifier.padding(16.dp)) }
    }
    if (compact) return

    var castChoice by remember { mutableStateOf(false) }
    if (castChoice) AlertDialog(
        onDismissRequest = { castChoice = false },
        title = { Text("Enviar a la TV") },
        text = {
            Column {
                Row(Modifier.fillMaxWidth().clickable {
                    castChoice = false
                    if (CastHelper.player == null || !CastHelper.chooseDevice(ctx)) {
                        Toast.makeText(ctx, "Chromecast no disponible en este móvil; usa duplicar pantalla", Toast.LENGTH_LONG).show()
                    }
                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Cast, null); Spacer(Modifier.width(14.dp))
                    Column { Text("Chromecast / Google TV"); Text("El vídeo se reproduce en la tele; el móvil hace de mando", color = Sub, fontSize = 12.sp) }
                }
                Row(Modifier.fillMaxWidth().clickable { castChoice = false; CastHelper.openScreenMirroring(ctx) }
                    .padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ScreenShare, null); Spacer(Modifier.width(14.dp))
                    Column { Text("Duplicar pantalla"); Text("Smart View, Miracast… (teles Samsung, LG, etc.)", color = Sub, fontSize = 12.sp) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { castChoice = false }) { Text("Cancelar") } },
    )

    Feed(vm, vm.related, header = {
        Column(Modifier.padding(12.dp)) {
            Text(v.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            DetailsSection(vm, v)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(if (vm.casting) Icons.Default.CastConnected else Icons.Default.Cast,
                    if (vm.casting) "Desconectar TV" else "Enviar a TV") {
                    if (vm.casting) CastHelper.disconnect(ctx) else castChoice = true
                }
                Pill(Icons.Default.PictureInPictureAlt, "Flotante") { (ctx as? MainActivity)?.enterPip() }
                Pill(Icons.Default.Download, if (vm.dlProgress == 1f) "Descargado" else "Descargar") { vm.download(ctx, share = false) }
                Pill(Icons.Default.Share, "Compartir") { vm.download(ctx, share = true) }
                Pill(Icons.Default.Link, "Enlace") {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, v.url), "Compartir enlace"))
                }
            }
            vm.dlProgress?.takeIf { it < 1f }?.let {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        LinearProgressIndicator(progress = { it }, color = YtRed, modifier = Modifier.fillMaxWidth())
                        Text("Descargando… ${(it * 100).toInt()} %", color = Sub, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Pill(Icons.Default.Close, "Cancelar") { vm.cancelDownload(ctx) }
                }
            }
            HorizontalDivider(Modifier.padding(top = 12.dp), color = Color(0xFF272727))
        }
    })
}

/** Pantalla completa: horizontal y sin barras del sistema; al salir, todo vuelve a la normalidad. */
@Composable
fun FullscreenEffect(full: Boolean) {
    val act = LocalContext.current as? android.app.Activity ?: return
    DisposableEffect(full) {
        val ctl = androidx.core.view.WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (full) {
            act.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            act.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }
}

@Composable
fun Pill(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF272727)).clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

fun fmtDur(s: Long) = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
private fun fmtViews(n: Long) = when {
    n >= 1_000_000 -> "%.1f M visualizaciones".format(n / 1e6)
    n >= 1_000 -> "%d K visualizaciones".format(n / 1000)
    else -> "$n visualizaciones"
}
