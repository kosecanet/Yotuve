package com.jose.mitube

import android.app.Application
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class App : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        instance = this
        scope.launch {
            try {
                YoutubeDL.getInstance().init(this@App)
                FFmpeg.getInstance().init(this@App)
                ready = true          // la app ya funciona con la versión instalada
            } catch (e: Exception) {
                Log.e("yotuve", "init yt-dlp", e); status = "Error iniciando yt-dlp"; return@launch
            }
            autoUpdate()             // y en segundo plano se actualiza, sin bloquear
        }
    }

    /** Actualiza yt-dlp en segundo plano en cada arranque (estable; si falla, nightly). */
    private fun autoUpdate() {
        scope.launch {
            status = "Buscando actualizaciones…"
            status = try {
                when (YoutubeDL.getInstance().updateYoutubeDL(this@App, YoutubeDL.UpdateChannel.STABLE)) {
                    YoutubeDL.UpdateStatus.DONE -> "yt-dlp actualizado a ${YoutubeDL.getInstance().versionName(this@App)}"
                    else -> null // ya estaba al día: no molestamos
                }
            } catch (e: Exception) {
                try {
                    YoutubeDL.getInstance().updateYoutubeDL(this@App, YoutubeDL.UpdateChannel.NIGHTLY); null
                } catch (_: Exception) { Log.w("yotuve", "update", e); null }
            }
            if (status != null) { kotlinx.coroutines.delay(4000); status = null }
        }
    }

    companion object {
        lateinit var instance: App
        @Volatile var ready = false
        /** Mensaje breve que la barra superior muestra mientras se actualiza. */
        var status by mutableStateOf<String?>(null)
    }
}
