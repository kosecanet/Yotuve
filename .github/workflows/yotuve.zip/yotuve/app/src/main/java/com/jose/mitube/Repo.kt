package com.jose.mitube

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Video(
    val id: String,
    val title: String,
    val channel: String,
    val duration: Long?,      // segundos
    val views: Long?,
    val thumb: String,
) {
    val url get() = "https://www.youtube.com/watch?v=$id"
}

/** Streams separados de vídeo y audio (YouTube ya no da >360p progresivo). */
data class Streams(val video: String, val audio: String?, val title: String)

object Repo {

    private suspend fun waitReady() {
        while (!App.ready) delay(100)
    }

    /** Sugerencias del buscador: el mismo endpoint que usa YouTube. */
    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        if (q.isBlank()) return@withContext emptyList()
        try {
            val u = "https://suggestqueries-clients6.youtube.com/complete/search?client=firefox&ds=yt&hl=es&gl=ES&q=" +
                URLEncoder.encode(q, "UTF-8")
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(txt).getJSONArray(1)
            List(arr.length()) { arr.getString(it) }.take(10)
        } catch (e: Exception) { emptyList() }
    }

    /** Búsqueda rápida con yt-dlp (--flat-playlist: no resuelve cada vídeo). */
    suspend fun search(q: String, count: Int = 25): List<Video> = withContext(Dispatchers.IO) {
        waitReady()
        val req = YoutubeDLRequest("ytsearch$count:$q").apply {
            addOption("--flat-playlist")
            addOption("-J")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(req).out
        val entries = JSONObject(out).optJSONArray("entries") ?: JSONArray()
        (0 until entries.length()).mapNotNull { i ->
            val e = entries.getJSONObject(i)
            val id = e.optString("id").takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            if (e.optString("ie_key") == "YoutubeTab") return@mapNotNull null // canales/listas fuera
            Video(
                id = id,
                title = e.optString("title"),
                channel = e.optString("channel", e.optString("uploader", "")),
                duration = e.optDouble("duration").takeIf { !it.isNaN() }?.toLong(),
                views = e.optLong("view_count", -1).takeIf { it >= 0 },
                thumb = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
            )
        }
    }

    /** Obtiene las URLs directas para reproducir (sin descargar). */
    suspend fun streams(v: Video, maxHeight: Int = 720): Streams = withContext(Dispatchers.IO) {
        waitReady()
        val req = YoutubeDLRequest(v.url).apply {
            addOption("-f", "bv*[height<=$maxHeight][ext=mp4]+ba[ext=m4a]/b[height<=$maxHeight]/b")
            addOption("-g")
            addOption("--no-playlist")
            addOption("--no-warnings")
        }
        val lines = YoutubeDL.getInstance().execute(req).out.lines().filter { it.startsWith("http") }
        Streams(lines[0], lines.getOrNull(1), v.title)
    }

    /**
     * Descarga con yt-dlp + ffmpeg (mezcla vídeo+audio en mp4).
     * Devuelve el fichero local (carpeta privada de la app, compartible con FileProvider)
     * y además lo copia a Descargas/MiTube para que se vea en la galería/archivos.
     */
    suspend fun download(ctx: Context, v: Video, onProgress: (Float) -> Unit): File = withContext(Dispatchers.IO) {
        waitReady()
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "").apply { mkdirs() }
        existing(ctx, v)?.let { return@withContext it }
        val req = YoutubeDLRequest(v.url).apply {
            addOption("-f", "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/bv*[height<=1080]+ba/b")
            addOption("--merge-output-format", "mp4")
            addOption("--no-playlist")
            addOption("--restrict-filenames")
            addOption("-o", "${dir.absolutePath}/%(title).80s [${v.id}].%(ext)s")
        }
        YoutubeDL.getInstance().execute(req, v.id) { p, _, _ -> onProgress(p / 100f) }
        val f = existing(ctx, v) ?: error("No se encontró el fichero descargado")
        publishToDownloads(ctx, f)
        f
    }

    fun existing(ctx: Context, v: Video): File? =
        ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?.listFiles { f -> f.name.contains("[${v.id}]") && f.extension == "mp4" }
            ?.firstOrNull()

    private fun publishToDownloads(ctx: Context, f: File) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/yotuve")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return
                ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            } else {
                @Suppress("DEPRECATION")
                val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "yotuve")
                d.mkdirs(); f.copyTo(File(d, f.name), overwrite = true)
            }
        } catch (_: Exception) { }
    }

    /** Extrae el id de un enlace compartido (youtu.be, watch?v=, shorts/). */
    fun idFromLink(text: String): String? =
        Regex("""(?:v=|youtu\.be/|shorts/|embed/)([\w-]{11})""").find(text)?.groupValues?.get(1)
}
