# yotuve

YouTube simplificado para Android: buscador con sugerencias de YouTube, reproducción rápida sin anuncios (yt-dlp + ExoPlayer con caché de 500 MB) y botones Descargar / Compartir (yt-dlp + ffmpeg).

## Compilar
1. Abre la carpeta `yotuve` en Android Studio (Ladybug o posterior).
2. Espera a que sincronice Gradle.
3. Build > Build APK(s). Instala `app-arm64-v8a-debug.apk` (móviles modernos) o el `universal`.

Por terminal: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.

## Uso
- Lupa: buscar con sugerencias en directo (la flecha ↖ completa la sugerencia).
- Toca un vídeo: se reproduce a 720p máx.; si lo vuelves a abrir, sale de la caché.
- Descargar: guarda MP4 (hasta 1080p) en Descargas/yotuve.
- Compartir: descarga y abre el menú para enviar el archivo (WhatsApp, Telegram…).
- Desde la app de YouTube o el navegador: Compartir > yotuve abre el vídeo.

## Notas
- yt-dlp se autoactualiza en segundo plano en cada arranque (canal estable, y nightly si falla); la app se puede usar mientras tanto.
- El primer arranque tarda unos segundos en preparar Python/yt-dlp.
